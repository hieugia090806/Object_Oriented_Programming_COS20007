﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SwinAdventure;
using NUnit.Framework; // Make sure you have this for [SetUp] and [Test]

namespace SwinAdventureTest
{
    public class PathsTest
    {
        Player player;
        Location library;
        Location principalroom;
        Paths path;
        //Setup
        [SetUp]
        public void SetUp()
        {
            player = new Player("Truong Ngoc Gia Hieu", "A brave Swinburne warrior");
            library = new Location("State Library", "A medium library");
            principalroom = new Location("Principal Room", "A personal room");
            path = new Paths(new string[] { "south" }, "Main Entrance", "The way to the Alizabeth Street", library);
            player.Location = principalroom; 
            principalroom.AddPath(path);
        }

        [Test]
        public void PathIdentifiabletest()
        {
            Location expected_1 = library;
            Location actual_1 = path.End;

            Location expected_2 = principalroom;
            Location actual_2 = player.Location;

            Assert.AreEqual(expected_1, actual_1);
            Assert.AreEqual(expected_2, actual_2);
        }
        [Test]
        public void PathNameTest()
        {
            string expected = "Main Entrance";
            string actual = path.FullDescription;
            Assert.AreEqual(expected, actual);
        }
        [Test]
        public void PathLocate()
        {
            GameObject expected = principalroom.FindPath("south");
            GameObject actual = path;
            Assert.AreEqual(expected, actual);
        }
    }
}