﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SwinAdventure;

namespace SwinAdventureTest
{
    public class LocationTest
    {
        Player player;
        Item axe;
        Location location;
        [SetUp]
        public void Setup()
        {
            player = new Player("Truong Ngoc Gia Hieu", "A brave Swinburne warrior");
            axe = new Item(new string[] { "axe" }, "Axe", "A wooden axe");
            location = new Location("Forest", "An unknown forest");
        }
        [Test]
        public void TestLocationIdentifiableItSelf()
        {
            Assert.That(location.AreYou("location"), Is.True);
        }
        [Test]
        public void TestLocationItemHave()
        {
            location.Inventory.Put(axe);
            Assert.That(location.Inventory.HasItem("axe"), Is.True);
        }
        [Test]
        public void TestPlayerCanLocateItemInTheirLocation()
        {
            location.Inventory.Put(axe);
            player.Location = location;
            GameObject expected = axe;
            GameObject actual = player.Location.Locate("axe");
            Assert.AreEqual(expected, actual);
        }
    }
}
