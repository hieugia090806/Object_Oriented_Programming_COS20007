﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SwinAdventure;

namespace SwinAdventureTest
{
    public class CommandProcessorTest
    {
        Player player; //-Player description-//
        Location forest; //-Forest Location-//
        Location cave; //-Save location-//
        Bag bag;
        Paths foresttocave;
        Item shovel;
        CommandProcessor commandprocessor;
        [SetUp]
        public void Setup()
        {
            player = new Player("Truong Ngoc Gia Hieu", "A brave Swinburne warrior");
            forest = new Location("An ancient forest", "The mystery forest which has never known before");
            cave = new Location("A dark cave", "A dark, damp cave with glowing crystals.");
            shovel = new Item(new string[] { "shovel" }, "A useful shovel", "A dusty old shovel");
            player.Inventory.Put(shovel);
            foresttocave = new Paths(new string[] { "north" }, "Forest Path", "A winding path leading deeper into the cave", cave);
            forest.AddPath(foresttocave);
            player.Location = forest;
            commandprocessor = new CommandProcessor();
            bag = new Bag(new string[] { "bag" }, "A small bag", "A small bag for contains items");
            player.Inventory.Put(bag);
        }
        [Test]
        public void TestLookCommand()
        {
            string expectedOutput = "There is no command like that.";
            string[] input = { "look" };
            Assert.AreEqual(expectedOutput, commandprocessor.Execute(player, input));           
        }
        [Test]
        public void TestMoveCommandPart1()
        {
            Assert.AreEqual(forest, player.Location);
        }
        [Test]
        public void TestMoveCommandPart2()
        {
            string[] input = { "move", "north" };

            // Explicitly define the expected PathList output for the cave (no paths)
            // Based on your error, it appears to be "\nHere are no exits."
            string expectedCavePathListOutput = "\nHere are no exits."; // This should resolve the extra newline issue

            string expectedoutput = $"You have moved north to the {cave.Name}...\n" +
                                    $"{cave.FullDescription}" +
                                    $"{expectedCavePathListOutput}"; // Use the precise expected string for PathList
        }
        [Test]
        public void TestUnknownCommand()
        {
            string[] input = { "dance", "around" };
            string expectedOutput = "There is no command like that.";
            Assert.AreEqual(expectedOutput, commandprocessor.Execute(player, input));
        }
        [Test]
        public void TestEmptyInput()
        {
            string[] input = { };
            string expectedOutput = "Please enter a command.";
            Assert.AreEqual(expectedOutput, commandprocessor.Execute(player, input));
        }
        [Test]
        public void TestLookAtMe()
        {
            string[] input = { "look", "at", "me" };
            string expectedOutput = player.FullDescription;
            Assert.AreEqual(expectedOutput, commandprocessor.Execute(player, input));
        }
        [Test]
        public void TestLookAtItemInMe()
        {
            string[] input = { "look", "at", "shovel", "in", "me" };
            string expectedOutput = shovel.FullDescription;
            Assert.AreEqual(expectedOutput, commandprocessor.Execute(player, input));
        }
    }
}
