﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SwinAdventure;

namespace SwinAdventureTest
{
    public class InventoryTest
    {
        Item axe;
        Item sword;
        Inventory inventory;
        [SetUp]
        public void Setup()
        {
            axe = new Item(new string[] { "axe" }, "A wooden axe", "+10 points Damage");
            sword = new Item(new string[] { "sword" }, "A sharp sword", "+20 points Damage");
            inventory = new Inventory();
        }
        [Test]
        public void TestFindItem()
        {
            inventory.Put(axe);
            inventory.Put(sword);
            Assert.That(inventory.HasItem("axe"), Is.True);
        }
        [Test]
        public void TestNoItemFind()
        {
            inventory.Put(axe);
            Assert.That(inventory.HasItem("sword"), Is.False);
        }
        [Test]
        public void TestFetchItem()
        {
            inventory.Put(axe);
            Item fetchedItem = inventory.Fetch("axe");
            Assert.That(fetchedItem, Is.EqualTo(axe));
        }
        [Test]
        public void TestTakeItem()
        {
            inventory.Put(axe);
            Item takenItem = inventory.Take("axe");
            Assert.That(takenItem, Is.EqualTo(axe));
            Assert.That(inventory.HasItem("axe"), Is.False);
        }
        [Test]
        public void TestItemList()
        {
            inventory.Put(axe);
            inventory.Put(sword);
            string expectedList = "A wooden axe: axe\nA sharp sword: sword\n";
            Assert.That(inventory.ItemList, Is.EqualTo(expectedList));
        }
    }
}
