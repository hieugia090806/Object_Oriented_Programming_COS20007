﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SwinAdventure;

namespace SwinAdventureTest
{
    public class PlayerTest
    {
        Player player;
        Item axe;
        Item sword;
        [SetUp]
        public void Setup()
        {
            axe = new Item(new string[] { "axe" }, "A wooden axe", "+10 points Damage");
            sword = new Item(new string[] { "sword" }, "A sharp sword", "+20 points Damage");
            player = new Player("Truong Ngoc Gia Hieu", "A brave Swinburne warrioe");
        }
        [Test]
        public void TestPlayerisIdentifiable()
        {
            Assert.That(player.AreYou("me"), Is.True);
            Assert.That(player.AreYou("inventory"), Is.True);
        }
        [Test]
        public void TestPlayerLocatesItems()
        {
            player.Inventory.Put(axe);
            player.Inventory.Put(sword);
            Assert.That(player.Inventory.HasItem("axe"), Is.True);
            Assert.That(player.Inventory.HasItem("sword"), Is.True);
        }
        [Test]
        public void TestPlayerLocateitSelf()
        {
            Player me = (Player)player.Locate("me");
            Player inventory = (Player)player.Locate("inventory");
            Assert.AreEqual(player, me);
            Assert.AreEqual(player, inventory);
        }
        [Test]
        public void TestPlayerFullDescription()
        {
            player.Inventory.Put(axe);
            player.Inventory.Put(sword);
            string expectedDescription = "Truong Ngoc Gia Hieu, A brave Swinburne warrioe\nList of Items that you have:\nA wooden axe: axe\nA sharp sword: sword\n";
            Assert.That(player.FullDescription, Is.EqualTo(expectedDescription));
        }

    }
}
