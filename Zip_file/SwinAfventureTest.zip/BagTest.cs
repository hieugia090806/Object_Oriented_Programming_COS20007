﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SwinAdventure;

namespace SwinAdventureTest
{
    public class BagTest
    {
        Bag bag;
        Item key;
        Item book;
        [SetUp]
        public void Setup()
        {
            bag = new Bag(new string[] { "bag" }, "A useful bag", "Contains items");
            key = new Item(new string[] { "key" }, "A small key", "Opens doors");
            book = new Item(new string[] { "book" }, "A thick book", "Contains knowledge");
        }
        [Test]
        public void TestBagsLocatesItems()
        {
            GameObject LocatedBag = bag.Locate("bag");
            Assert.That(LocatedBag, Is.EqualTo(bag));
        }
        [Test]
        public void TestBagLocatesitself()
        {
            bag.Inventory.Put(key);
            GameObject LocatedKey = bag.Locate("key");
            Assert.That(LocatedKey, Is.EqualTo(key));
        }
        [Test]
        public void TestBagLocatesNothing()
        {
            GameObject LocatedNothing = bag.Locate("nothing");
            Assert.That(LocatedNothing, Is.Null);
        }
        [Test]
        public void TestBagFullDescription()
        {
            bag.Inventory.Put(key);
            bag.Inventory.Put(book);
            string expectedDescription = "In A useful bag you can see:\nA small key: key\nA thick book: book\n";
            Assert.That(bag.FullDescription, Is.EqualTo(expectedDescription));
        }

    }
}
