﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SwinAdventure;

namespace SwinAdventureTest
{
    public class ItemTest
    {
        Item axe;
        Item sword;
        Inventory inventory;
        [SetUp]
        public void Setup()
        {
            axe = new Item(new string[] { "axe"}, "A wooden axe", "+10 points Damage");
            sword = new Item(new string[] { "sword" }, "A sharp sword", "+20 points Damage");
            inventory = new Inventory();
        }
        [Test]
        public void TestItemisIdentifiable()
        {
            inventory.Put(axe);
            inventory.Put(sword);
            Assert.That(inventory.HasItem("axe"), Is.True);
            Assert.That(inventory.HasItem("sword"), Is.True);
        }
        [Test]
        public void TestShortDescription()
        {
            Assert.That(axe.ShortDescription, Is.EqualTo("A wooden axe: axe"));
            Assert.That(sword.ShortDescription, Is.EqualTo("A sharp sword: sword"));
        }
        [Test]
        public void TestFullDescription()
        {
            Assert.That(axe.FullDescription, Is.EqualTo("+10 points Damage"));
            Assert.That(sword.FullDescription, Is.EqualTo("+20 points Damage"));
        }
        [Test]
        public void TestPrivilegeEscalation()
        {
            axe.PrivilegeEscalation("105565520");
            Assert.That(axe.FirstId, Is.EqualTo("COS20007"));
        }
    }
}
