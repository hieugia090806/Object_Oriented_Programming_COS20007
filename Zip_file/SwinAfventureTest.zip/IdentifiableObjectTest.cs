using System.Diagnostics.Contracts;
using SwinAdventure;

namespace SwinAdventureTest
{
    public class IdentifiableObjectTest
    {
        IdentifiableObject id;
        [SetUp]
        public void Setup()
        {
            id = new IdentifiableObject(new string[] { "105565520", "Hieu", "Truong"});
        }
        [Test]
        public void TestAreYou()
        {
            Assert.That(id.AreYou("105565520"), Is.True);
            Assert.That(id.AreYou("Hieu"), Is.True);
        }
        [Test]
        public void TestNotAreYou()
        {
            Assert.That(id.AreYou("JoHn"), Is.False);
            Assert.That(id.AreYou("JEnNIE"), Is.False);
        }
        [Test]
        public void TestCaseSensitive()
        {
            Assert.That(id.AreYou("HieU"), Is.True);
            Assert.That(id.AreYou("TrUOnG"), Is.True);
        }
        [Test]
        public void TestFirstId()
        {
            Assert.That(id.AreYou("105565520"), Is.True);
        }
        [Test]
        public void TestFirstIDWithNoIDs()
        {
            Assert.That(id.AreYou(""), Is.False);
        }
        [Test]
        public void TestAddId()
        {
            id.AddIdentifier("Jennie");
            Assert.That(id.AreYou("JenniE"), Is.True);
        }
        [Test]
        public void TestPrivilegeEscalation()
        {
            id.PrivilegeEscalation("105565520");
            Assert.That(id.FirstId, Is.EqualTo("COS20007"));
        }
    }
}
