﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using SwinAdventure;

namespace SwinAdventureTest
{
    public class MoveCommandTest
    {
        Player player;
        Location mainhall;
        Location library;
        Location principalroom;
        Paths north;
        Paths east;
        MoveCommand movecommand;
        [SetUp]
        public void SetUp()
        {
            player = new Player("Truong Ngoc Gia Hieu", "A brave Swinburne warrior");
            mainhall = new Location("Community Hall", "A large hall for celebrating events");
            library = new Location("State library", "An interesting library where people work and study");
            principalroom = new Location("Principla Room", "Room of principle of a school");
            north = new Paths(new string[] { "north" }, "First door", "The way to the library", library);
            east = new Paths(new string[] { "east" }, "Second door", "The way to the Principle Room", principalroom);
            player.Location = mainhall;
            mainhall.AddPath(north);
            mainhall.AddPath(east);
            movecommand = new MoveCommand();
        }
        [Test]
        public void MoveTestSucccessful()
        {
            //Player starts at mainhall
            Assert.AreEqual(mainhall, player.Location, "Player should start in mainhall");
            //Move go to north
            string result = movecommand.Execute(player, new string[] { "move", "north" });
            //Assert that player's location changed to the library
            Assert.AreEqual(library, player.Location, "Player should have moved to the library");
        }
        [Test]
        public void TestMoveEastSuccessful()
        {
            Assert.AreEqual(mainhall, player.Location);
            string result = movecommand.Execute(player, new string[] { "go", "east" });
            Assert.AreEqual(principalroom, player.Location);
        }
        [Test]
        public void MoveTestFail()
        {
            Location startingLocation = player.Location;
            string result = movecommand.Execute(player, new string[] { "move", "south" });
            Assert.AreEqual(startingLocation, player.Location, "Player should still be in the main hall after failed move");
        }
    }
}
