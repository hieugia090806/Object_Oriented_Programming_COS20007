﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SwinAdventure;

namespace SwinAdventure
{
    public class Player : GameObject, IHaveInventory
    {
        //Attributes
        private Inventory _inventory;
        //Constructor & Methods
        public Player(string name, string desc) : base(new string[] { "me", "inventory"}, name, desc)
        {
            _inventory = new Inventory();
        }
        public GameObject Locate(string id)
        {
            if (AreYou(id))
                return this;
            if (Inventory.HasItem(id))
                return Inventory.Fetch(id);
            return null;
        }
        public override string FullDescription
        {
            get
            {
                return $"{Name}, {base.FullDescription}\nList of Items that you have:\n{ _inventory.ItemList}";
            }
        }
        public Inventory Inventory
        {
            get
            {
                return _inventory;
            }
        }
        //New methods
        private Location _location;
        public Location Location
        {
            get
            {
                return _location;
            }
            set
            {
                _location = value;
            }
        }
        public void Move(Paths MovePath)
        {
            if (Location.PathExists(MovePath) && MovePath.End != null)
            {
                Location = MovePath.End;
            }
        }
    }
}
