﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SwinAdventure;

namespace SwinAdventure
{
    public class Paths : GameObject
    {
        //Attributes
        private bool _LockablePath;
        private Location _end;
        //Constructor & Methods
        public Paths(string[] idents, string name, string desc, Location end) : base(idents, name, desc)
        {
            _end = end;
            _LockablePath = false;
            AddIdentifier("path");
        }
        public Location End
        {
            get { return _end; }
        }
        public override string FullDescription
        {
            get
            {
                return Name;
            }
        }
        public bool LockablePath
        {
            get
            {
                return _LockablePath;
            }
            set
            {
                _LockablePath = value;
            }
        }
    }
}
