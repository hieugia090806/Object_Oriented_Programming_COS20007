﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using SwinAdventure;

namespace SwinAdventure
{
    public class Location : GameObject, IHaveInventory
    {
        //Attributes
        private Inventory _inventory;
        List<Paths> _paths; //New attribute
        //Constructor and methods
        public Location(string name, string desc) : base(new string[] { "location" }, name, desc)
        {
            _inventory = new Inventory();
            _paths = new List<Paths>(); //New code line
        }
        //New constructor
        public Location(string name, string desc, List<Paths> paths) : this(name, desc)
        {
            _paths = paths;
        }
        public GameObject Locate(string id)
        {
            if (AreYou(id))
                return this;
            foreach (var item in _inventory.Items)
            {
                if (item.AreYou(id))
                    return item;
            }
            return null;
        }
        public override string FullDescription
        {
            get
            {
                return $"{Name}, You are in {base.FullDescription}\nItems that available here:\n{_inventory.ItemList}";
            }
        }

        public Inventory Inventory
        {
            get { return _inventory; }
        }
        //New methods
        public Paths FindPath(string id)
        {
            foreach (Paths path in  _paths)
            {
                if (path.AreYou(id))
                {
                    return path;
                }
            }
            return null;
        }
        public void AddPath(Paths path)
        {
            _paths.Add(path);
        }
        public string PathList
        {
            get
            {
                if (_paths.Count == 0)
                {
                    return "\nHere are no exits.";
                }
                else
                {
                    string List = "\nPaths that you can go to:\n";
                    foreach (Paths path in _paths)
                    {
                        List += path.FirstId + "\n";
                    }
                    return List;
                }
            }
        }
        public bool PathExists(Paths CheckPath)
        {
            return _paths.Contains(CheckPath);
        }
        public string InventoryDescription
        {
            get
            {
                if (_inventory.Items.Count() == 0)
                {
                    return "There's no available item.";
                }
                return _inventory.ItemList;
            }
        }
    }
}
