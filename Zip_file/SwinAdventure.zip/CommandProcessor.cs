﻿//-The CommandProcessor class has to inherit from Command so far because:-//
//-Firstly, It can be treated like any other command-//
//-Secondly, it has Execute method to process and delegate user commands.-//
//-Lastly, It provides a consistent and extensible way to handle all game commands.-//
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SwinAdventure;

namespace SwinAdventure
{
    public class CommandProcessor : Command
    {
        //-Attributes-//
        List<Command> _commands;
        //-Constructor-//
        public CommandProcessor() : base(new string[] {"command"})
        {
            _commands = new List<Command>();
            _commands.Add(new LookCommand());
            _commands.Add(new MoveCommand());
        }
        //-Methods-//
        public override string Execute(Player p, string[] text)
        {
            if (text.Length == 0)
            {
                return "Please enter a command.";
            }
            else if (text.Length > 1)
            {
                string commandId = text[0].ToLower();

                foreach (Command cmd in _commands)
                {
                    if (cmd.AreYou(commandId))
                    {
                        return cmd.Execute(p, text);
                    }
                }
            }
            return "There is no command like that."; // Or "I don't know that command." based on your preference
        }
    }
}
