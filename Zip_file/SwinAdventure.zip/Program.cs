﻿using System;
using System.ComponentModel.Design; // Not strictly necessary, but kept from original.

namespace SwinAdventure
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Print sentences to the console window
            Console.WriteLine("WELCOME TO THE SWINADVENTURE GAME!");
            Console.WriteLine("----------------------------------");
            // Enter player name and player description
            Console.Write("Dear Warrior, please enter your name: ");
            string playername = Console.ReadLine();
            Console.Write("Please enter your description: ");
            string playerdescription = Console.ReadLine();
            Player player = new Player(playername, playerdescription);
            // Set up initial items
            Item axe = new Item(new string[] { "sword" }, "a sharp sword", "+20 ATK points");
            Item shield = new Item(new string[] { "shield" }, "a bronze shield", "+5 DEF points ");
            Bag backpack = new Bag(new string[] { "backpack" }, "A heavy backpack", "Contains crucial items");
            // Put items into the player's inventory
            player.Inventory.Put(axe);
            player.Inventory.Put(shield);
            player.Inventory.Put(backpack);
            // Create items and put them into the backpack
            Item gun = new Item(new string[] { "gun" }, "An AK-47 gun", "+15 ATK points");
            backpack.Inventory.Put(gun);
            Item shovel = new Item(new string[] { "shovel" }, "An useful shovel", "+10 ATK points");
            backpack.Inventory.Put(shovel);
            Item map = new Item(new string[] { "map" }, "A detailed map", "Used for showing directions");
            backpack.Inventory.Put(map);
            Item book = new Item(new string[] { "book" }, "A thick book", "Contains knowledge of human");
            backpack.Inventory.Put(book);
            //Paths, Directions, and Locations
            Location university = new Location("An old university", "A mystery university");
            Location library = new Location("State Library", "An old and unforgettable library");
            Location mainhall = new Location("School Mainhall", "A large mainhall of a university");
            Location principalroom = new Location("Principal Room", "The pricipal room");
            Location pavement = new Location("A pavement", "Outside of the university");
            Location street = new Location("A street", "The Alizabeth street");

            Paths pavementtoMainHall = new Paths(new string[] { "forward", "north" }, "forward path", "The way to the Main Hall of the University", mainhall);
            Paths mainhalltopavement = new Paths(new string[] { "backward", "south" }, "backward path", "The way back to the pavement", pavement);
            Paths mainhalltolibrary = new Paths(new string[] { "north" }, "north path", "The way to the Library of the University", library);
            Paths mainhalltoprincipalroom = new Paths(new string[] { "east" }, "east path", "The way to the Principal Room of the University", principalroom);
            Paths pavementtostreet = new Paths(new string[] { "backward", "south" }, "backward street", "The way to the Elizaberth Street", street);
            Paths streettopavement = new Paths(new string[] { "forward", "north" }, "forward path", "The way back to the pavement", pavement);
            Paths librarytomainhall = new Paths(new string[] { "backward", "south" }, "backward path", "The way back to the MainHall", mainhall);
            Paths principalroomtomainhall = new Paths(new string[] { "backward", "north" }, "Return Main Hall path", "The way back from Principal Room to Main Hall", mainhall);

            pavement.AddPath(pavementtoMainHall);
            pavement.AddPath(pavementtostreet);
            mainhall.AddPath(mainhalltopavement);
            mainhall.AddPath(mainhalltolibrary);
            mainhall.AddPath(mainhalltoprincipalroom);
            library.AddPath(librarytomainhall);
            street.AddPath(streettopavement);
            principalroom.AddPath(principalroomtomainhall);

            //Create some items and put them in rooms
            Item diary = new Item(new string[] { "diary" }, "A principal's diary", "Thw diary which takes important event.");
            principalroom.Inventory.Put(diary);
            Item handledlamp = new Item(new string[] { "handledlamp" }, "A useful handledlamp", "The handledlamp is full of energy and can be used in anytime");
            library.Inventory.Put(handledlamp);

            //Set default location to the player
            player.Location = pavement;

            // Set up command handler - NOW USING CommandProcessor!
            // THIS IS THE KEY CHANGE: Instantiate CommandProcessor
            CommandProcessor processor = new CommandProcessor();

            // Print the player name and full description
            Console.Write($"\nHello, {player.Name}!\n{player.FullDescription}");
            Console.Write("-------------------------------------");
            Console.Write($"\n{player.Location.FullDescription}");
            Console.Write("-------------------------------------");
            Console.Write(player.Location.PathList);
            Console.WriteLine("-------------------------------------");

            //Main loop
            while (true)
            {
                Console.Write("Enter your command: ");
                string commandline = Console.ReadLine();

                if (string.IsNullOrEmpty(commandline))
                {
                    Console.WriteLine("Please enter the command again.");
                }
                else if (commandline.ToLower() == "exit")
                {
                    Console.WriteLine("Thank you for spending time to play SwinAdventure game. See you next time!");
                    break;
                }
                else
                {
                    string[] commandsentence = commandline.ToLower().Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    // THIS IS THE KEY CHANGE: Call CommandProcessor.Execute
                    string result = processor.Execute(player, commandsentence);
                    Console.WriteLine(result);
                }
            }
        }
    }
}